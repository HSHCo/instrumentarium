// UTouchCD.h
// ----------
//
// Since there are slight deviations in all touch screens you should run a
// calibration on your display module. Run the UTouch_Calibration sketch
// that came with this library and follow the on-screen instructions to
// update this file.
//
// Remember that is you have multiple display modules they will probably 
// require different calibration data so you should run the calibration
// every time you switch to another module.
// You can, of course, store calibration data for all your modules here
// and comment out the ones you dont need at the moment.
//

// These calibration settings works with my ITDB02-3.2S.
// They MIGHT work on your display module, but you should run the
// calibration sketch anyway.
// work KLL 28.02.2013
//org #define CAL_X 0x00378F66UL
//org #define CAL_Y 0x03C34155UL
//org #define CAL_S 0x000EF13FUL

//step1 #define CAL_X 0x004A9044UL
//step1 #define CAL_Y 0x009B0ECEUL
//step1 #define CAL_S 0x000EF18FUL

//step2 #define CAL_X 0x003C52D7UL
//step2 #define CAL_Y 0x00A78F71UL
//step2 #define CAL_S 0x000EF18FUL
//step3 
#define CAL_X 0x00514F8EUL
#define CAL_Y 0x0050CEB2UL
#define CAL_S 0x000EF18FUL

//step4 #define CAL_X 0x003E18ABUL
//step4 #define CAL_Y 0x01781131UL
//step4 #define CAL_S 0x000EF18FUL
