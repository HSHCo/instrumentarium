/*
  Emon.cpp - Library for openenergymonitor
  Created by Trystan Lea, April 27 2010
  GNU GPL
*/
/* MOD KLL, MAY 2012     */

#include "EmonLib.h"

#if defined(ARDUINO) && ARDUINO >= 100

#include "Arduino.h"

#else

#include "WProgram.h"

#endif

#define usecurrentdropout 0.01
#define usephasedropout 0.5

#define useMEGA        //  switch use MEGA with 8K RAM and min 128K FLASH  
#define useMEGAT1      // see also main tab.


//--------------------------------------------------------------------------------------
// Sets the pins to be used for voltage and current sensors
//--------------------------------------------------------------------------------------
void EnergyMonitor::voltage(int _inPinV, double _VCAL, double _PHASECAL)
{
   inPinV = _inPinV;
   VCAL = _VCAL;
   PHASECAL = _PHASECAL;
}

void EnergyMonitor::current(int _inPinI, double _ICAL)
{
   inPinI = _inPinI;
   ICAL = _ICAL;
}

void EnergyMonitor::KWHstart(long _KWH) 
{ 
    KWH = _KWH; 
}



//--------------------------------------------------------------------------------------
// Sets the pins to be used for voltage and current sensors based on emontx pin map
//--------------------------------------------------------------------------------------
void EnergyMonitor::voltageTX(double _VCAL, double _PHASECAL)
{
   inPinV = 2;
   VCAL = _VCAL;
   PHASECAL = _PHASECAL;
}

void EnergyMonitor::currentTX(int _channel, double _ICAL)
{
   if (_channel == 1) inPinI = 3;
   if (_channel == 2) inPinI = 0;
   if (_channel == 3) inPinI = 1;
   ICAL = _ICAL;
}

//--------------------------------------------------------------------------------------
// emon_calc procedure
// Calculates realPower,apparentPower,powerFactor,Vrms,Irms,kwh increment
// From a sample window of the mains AC voltage and current.
// The Sample window length is defined by the number of wavelengths we choose to measure.
// KLL revision with FULL WAVE EMON
//--------------------------------------------------------------------------------------
void EnergyMonitor::calcVI(int wavelengths, int timeout, boolean diagp,boolean emon_zerodropout)
{
  int SUPPLYVOLTAGE = readVcc();
  int crossCount = 0;                             //Used to measure number of times threshold is crossed.
  int numberOfSamples = 0;                        //This is now incremented  

  //-------------------------------------------------------------------------------------------------------------------------
  // 1) Waits for the waveform to be close to 'zero' (500 adc) part in sin curve.
  //-------------------------------------------------------------------------------------------------------------------------
  st=false;                                  //an indicator to exit the while loop
  
  startp = micros();    // makes sure it doesnt get stuck in the loop if there is an error.

  while(st==false)                                   //the while loop...
  {
     laststartV = startV;                            // remember old value
     startV = analogRead(inPinV);                    //using the voltage waveform
      if ((micros()-startp)/1000>timeout) st = true;       // check on timeout
      if ( laststartV < 511 && laststartV > 0 && startV >= 511 ) {  st = true;  }    // sinus starts and NOT programstart
  }  // END st 
  
if (diagp) {     // only for see in printout!!
  // program start detect:
  if (sampleV == 0 ) {   // program start  ( or no hardware connected )
                       sampleV = analogRead(inPinV);      // new program init not use "0" at program start
                       sampleI = analogRead(inPinI);
                     }
           }
  

  //-------------------------------------------------------------------------------------------------------------------------
  // 2) Main measurment loop
  //------------------------------------------------------------------------------------------------------------------------- 

  

 if (diagp) {  
 startb = micros();   // only for print , error by serial delay

Serial.print(F(",pause,")); Serial.print(startb-endb);
Serial.print(F(",sampleV, ")); Serial.print(sampleV);
Serial.print(F(",filteredV, ")); Serial.print(filteredV);
Serial.print(F(",sampleI, ")); Serial.print(sampleI);
Serial.print(F(",filteredI, ")); Serial.print(filteredI);
Serial.print(F(",startV, ")); Serial.print(startV);
//Serial.print(","); Serial.println();
         }
         
  if (sampleV == 0 ) {   // program start  ( or no hardware connected )
                       sampleV = analogRead(inPinV);      // new program init not use "0" at program start
                       sampleI = analogRead(inPinI);
                     }
               
  // batch start
  startb = micros();    
//  start = millis();      
//  while ((crossCount < wavelengths) && ((micros()-startb)/1000<timeout))   // 2.36kHz
//  while ((crossCount < wavelengths) && ((millis()-start)<timeout))         // 2.59kHz  ORIGINAL
  while ((crossCount < wavelengths) && (numberOfSamples < wavelengths*100))  // 2.62kHz , timeout 40fullwave * 100 = 4000samples = 1.5sec
  {
    numberOfSamples++;                            //Count number of times looped.
    
    //-----------------------------------------------------------------------------
    // A) Read in raw voltage and current samples
    //-----------------------------------------------------------------------------
    lastSampleV=sampleV;                          //Used for digital high pass filter
    lastSampleI=sampleI;                          //Used for digital high pass filter

    sampleV = analogRead(inPinV);                 //Read in raw voltage signal
    sampleI = analogRead(inPinI);                 //Read in raw current signal

    //-----------------------------------------------------------------------------
    // B) Apply digital high pass filters to remove 2.5V DC offset (centered on 0V).
    //-----------------------------------------------------------------------------
    lastFilteredV = filteredV;                    //Used for offset removal
    lastFilteredI = filteredI;                    //Used for offset removal         
    
    filteredV = 0.996*(lastFilteredV+sampleV-lastSampleV);
    filteredI = 0.996*(lastFilteredI+sampleI-lastSampleI);
   
    //-----------------------------------------------------------------------------
    // C) Root-mean-square method voltage
    //-----------------------------------------------------------------------------  
    sqV= filteredV * filteredV;                 //1) square voltage values
    sumV += sqV;                                //2) sum
    
    //-----------------------------------------------------------------------------
    // D) Root-mean-square method current
    //-----------------------------------------------------------------------------   
    sqI = filteredI * filteredI;                //1) square current values
    sumI += sqI;                                //2) sum 
    
    //-----------------------------------------------------------------------------
    // E) Phase calibration
    //-----------------------------------------------------------------------------
    phaseShiftedV = lastFilteredV + PHASECAL * (filteredV - lastFilteredV); 
    
    //-----------------------------------------------------------------------------
    // F) Instantaneous power calc
    //-----------------------------------------------------------------------------   
    instP = phaseShiftedV * filteredI;          //Instantaneous Power
    sumP +=instP;                               //Sum  
    
    //-----------------------------------------------------------------------------
    // G) Find the number of times the voltage has crossed the 511 from minus to plus
    //-----------------------------------------------------------------------------       
      if ( lastSampleV < 511 && sampleV >= 511 ) { crossCount++;  }    // next sinus starts

  }  // end while emon sample batch
endb=micros();
  //-------------------------------------------------------------------------------------------------------------------------
  // 3) Post loop calculations
  //------------------------------------------------------------------------------------------------------------------------- 
  //Calculation of the root of the mean of the voltage and current squared (rms)
  //Calibration coeficients applied. 
  
  freq = float(crossCount)*1000000.0/float(endb - startb);                          // kll
  
  double V_RATIO = VCAL *((SUPPLYVOLTAGE/1000.0) / 1023.0);
  Vrms = V_RATIO * sqrt(sumV / numberOfSamples); 
  
  double I_RATIO = ICAL *((SUPPLYVOLTAGE/1000.0) / 1023.0);
  Irms = I_RATIO * sqrt(sumI / numberOfSamples); 

  //Calculation power values
  realPower = V_RATIO * I_RATIO * sumP / numberOfSamples;
  if(emon_zerodropout) {
  if ( realPower < 0.0 ) { realPower = 0.0; }     // KLL, dont like the negative Watt here
  if ( Irms < usecurrentdropout )    { Irms = 0.0; }          // KLL, bad ZERO
                       }
                       
  apparentPower = Vrms * Irms;
  if ( apparentPower != 0.0 ) { powerFactor = realPower / apparentPower; } else { powerFactor = 0.0; }   // have the funny ,nan,p, sometimes
  
  if(emon_zerodropout) {  
  if ( powerFactor < usephasedropout ) {           // new ZERO DROP OUT
  Irms = 0.0;
  apparentPower = 0.0;
  powerFactor = 0.0;
  realPower = 0.0;
  }
}
  
  //Reset accumulators
  sumV = 0;
  sumI = 0;
  sumP = 0;
  

//--------------------------------------------------------------------------------------
// use start variable for mWh and in millis
    start = millis();
    if ( start < lwhtime ) { mWH = mWH + realPower*float(5130)/3600.0;      //  overflow   use average cycle time in millis 
                           } else { 
                             mWH = mWH + realPower*float(start-lwhtime)/3600.0;   }                     // 
    lwhtime = start;
    if ( mWH > 1000000.0 ) { KWH = KWH + 1; mWH = mWH - 1000000.0; }          // KWH can be stored to EEPROM, SDcard... for powerfail/reset...
    

  endp=micros();
if (diagp) { 
  Serial.print(F(",search, ")); Serial.print(startb-startp); 
  Serial.print(F(",batch, ")); Serial.print(endb-startb); 
  Serial.print(F(",calc, ")); Serial.print(endp-endb);   
  Serial.print(F(",samples, "));Serial.print(numberOfSamples);
  Serial.print(F(",samplef, "));Serial.print(numberOfSamples*1000.0/float((endb-startb)/1000));
  Serial.print(F(",crosses, "));Serial.print(crossCount);
  Serial.print(F(", "));
}  // end diagp

} // end calcVI
//--------------------------------------------------------------------------------------       

//--------------------------------------------------------------------------------------
double EnergyMonitor::calcIrms(int NUMBER_OF_SAMPLES)
{
  int SUPPLYVOLTAGE = readVcc();
  
  for (int n = 0; n < NUMBER_OF_SAMPLES; n++)
  {
    lastSampleI = sampleI;
    sampleI = analogRead(inPinI);
    lastFilteredI = filteredI;
    filteredI = 0.996*(lastFilteredI+sampleI-lastSampleI);

    // Root-mean-square method current
    // 1) square current values
    sqI = filteredI * filteredI;
    // 2) sum 
    sumI += sqI;
  }

  double I_RATIO = ICAL *((SUPPLYVOLTAGE/1000.0) / 1023.0);
  Irms = I_RATIO * sqrt(sumI / NUMBER_OF_SAMPLES); 

  //Reset accumulators
  sumI = 0;
//--------------------------------------------------------------------------------------       
 
  return Irms;
}

void EnergyMonitor::serialprint()                                    // kll 
{
const char WATTstr[4]=",W,";
const char VAstr[5]=",VA,";
const char VOLTstr[4]=",V,";
const char AMPstr[4]=",A,";
const char KWHstr[6]=",kWh,";
const char Pstr[4]=",p,";
const char HZstr[5]=",Hz,";
const char termsep=','; 
  byte screensep=',';

  
    Serial.println(); 
    Serial.print('A');
    Serial.print(inPinI);
    Serial.write(screensep);
    Serial.print(realPower);         Serial.print(WATTstr);

    Serial.print(apparentPower);     Serial.print(VAstr);

    Serial.print(Vrms);              Serial.print(VOLTstr);

    Serial.print(Irms);              Serial.print(AMPstr);

    Serial.print(powerFactor);       Serial.print(Pstr);

    Serial.print(freq);              Serial.print(HZstr);


    Serial.print(float(KWH) + mWH/1000000.0 );     Serial.print(KWHstr);


//    Serial.println();    
//    delay(100); 

#if defined(useMEGAT1)
    //Serial1.print(termsep);
    Serial1.print('A');    Serial1.print(inPinI);        Serial1.print(termsep);
    Serial1.print(realPower);     Serial1.print(termsep);
    Serial1.print(apparentPower); Serial1.print(termsep);
    Serial1.print(Vrms);          Serial1.print(termsep);
    Serial1.print(Irms);          Serial1.print(termsep);
    Serial1.print(powerFactor);   Serial1.print(termsep);
    Serial1.print(freq);          Serial1.print(termsep);
    Serial1.print(float(KWH) + mWH/1000000.0 );    Serial1.print(termsep);
    Serial1.print('\r'); 
    //Serial.print("T1 send,");
#endif


}

// http://code.google.com/p/tinkerit/wiki/SecretVoltmeter

long EnergyMonitor::readVcc() {
  long result;
#if defined (__AVR_ATmega328P__)   
  ADMUX = _BV(REFS0) | _BV(MUX3) | _BV(MUX2) | _BV(MUX1);
    delay(2);
  ADCSRA |= _BV(ADSC);

  while (bit_is_set(ADCSRA,ADSC));
  result = ADCL;
  result |= ADCH<<8;
  result = 1126400L / result;
  
#endif    
  
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)     //|| defined(__AVR_ATmega1284P__)

//  ADMUX = BV(REFS0) | BV(MUX4) | BV(MUX3) | BV(MUX2) | BV(MUX1);
//  ADMUX = _BV(REFS0) | _BV(MUX4) | _BV(MUX3) | _BV(MUX2) | _BV(MUX1);
//  delay(2);
//  ADCSRB &= ~BV(MUX5);  // MEGA
//  ADCSRB |= _BV(MUX5);
//  while (bit_is_set(ADCSRB,ADSC));  //SRA ? SRB ?
//  result = ADCL;
//  result |= ADCH<<8;
//  result = 1126400L / result;
result = 5000;
#endif  
  
#if defined(__PIC32MX__)
result = 3300;   // PIC board 5V but PIC CPU and ADC runs on 3V3 
#endif 
    
  return result;
}

